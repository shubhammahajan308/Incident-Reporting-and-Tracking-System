function submitdata()
{
	document.getElementById("overlay").style.display = "block";
	var name=document.getElementById("name").value;
	var email=document.getElementById("Email").value;
	if(name==""||email=="")
		{
		 document.getElementById("overlay").style.display = "none";
		alert("Both field are mandatory");
		}
	else
		{
	getLocation();
		}
}
function getLocation() {
	  if (navigator.geolocation) {
	    navigator.geolocation.getCurrentPosition(showPosition);
	  } else {
	   document.getElementById("overlay").style.display = "none";
	    alert("Please allow to read your loaction..!");
	  }
	}

	function showPosition(position) {
		var baseurl=window.location.origin;
		var lat=position.coords.latitude;
		var long=position.coords.longitude;
		var name=document.getElementById("name").value;
		var email=document.getElementById("Email").value;
		var data="{name:'"+name+"',emailid:'"+email+"',latitude:'"+lat+"',longitude:'"+long+"'}";
	//	alert("Latitude: " + position.coords.latitude +"<br>Longitude: " + position.coords.longitude);
		
		//alert(data);
		var xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
		    if (this.readyState == 4 && this.status == 200) {
		     // document.getElementById("demo").innerHTML = this.responseText;
		      
		      if(this.responseText>0)
		    	  {
		    	  document.getElementById("overlay").style.display = "none";
		    	  alert("DATA SAVED SUCCESSFULLY");
		    	  }
		      if(this.responseText==0)
		    	 {
		    	 document.getElementById("overlay").style.display = "none";
		    	  alert("INVALID JSON DATA");
		    	 }
		    }
		  };
		  xhttp.open("POST", baseurl+"/demoapp/spring/k/10", true);
		  xhttp.setRequestHeader("Content-type", "text/plain");
		  xhttp.send(data);
	}