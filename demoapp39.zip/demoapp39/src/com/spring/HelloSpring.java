package com.spring;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.spring.daoo.UserDaoImple;
import com.spring.dto.Complaint;
import com.spring.service.*;

import org.json.JSONObject;
import org.json.JSONArray;

@RestController
@RequestMapping("/k")
public class HelloSpring {
	

	UserDaoImple userImpl=new UserDaoImple();
	
	
	@PostMapping(value="/10", consumes ="text/plain")
	public ModelAndView helloPostMapping(@RequestBody String  std) 
	{
	 int flag;
	 System.out.println(std);
		JSONObject jsonObj = new JSONObject(std.toString());  
		if(jsonObj.has("latitude")&&jsonObj.has("longitude"))
		{
			   if(jsonObj.getString("latitude").equals("")||jsonObj.getString("longitude").equals(""))
			   {
				   flag=-1;
			   }
			   else
			   {
				   String lattitude=jsonObj.getString("latitude");
					 String longitude=jsonObj.getString("longitude");
					 
					
				   System.out.println("***********************");
				   userImpl.shareLocation(lattitude,longitude);
						   flag=1;
			   }
		}
		else
		{
			flag=0;
		}
		String message="Location Shared Successfully";
		return new ModelAndView("successComplaint","message",message) ;
	}
	
	
	@GetMapping
	@RequestMapping("/getMapList")
	    public List<Complaint> getStudentsAll() {


	        return PrepareDataClass.getStudents();
	    }
	
	@GetMapping
	@RequestMapping("/getComplaintsList/{someID}")
	    public List<Complaint> getCasesByStatus(@PathVariable(value="someID") String id,String someAttr) {

		return PrepareDataClass.getCasesByStatus(id);
	      //  return PrepareDataClass.getStudents();
	    }
	
	
	
}
