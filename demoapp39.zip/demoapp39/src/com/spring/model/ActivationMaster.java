package com.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="ActivationMaster")
public class ActivationMaster {

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	 @Column (name="email",unique=true)
	private String email;
	private String role="Admin";
	private String selfOTP;
	private String activationOTP;
	private char isVerified;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getSelfOTP() {
		return selfOTP;
	}
	public void setSelfOTP(String selfOTP) {
		this.selfOTP = selfOTP;
	}
	public String getActivationOTP() {
		return activationOTP;
	}
	public void setActivationOTP(String activationOTP) {
		this.activationOTP = activationOTP;
	}
	public char isVerified() {
		return isVerified;
	}
	public void setVerified(char isVerified) {
		this.isVerified = isVerified;
	}
	
	
}
