package com.spring.model;

public class AreaMapping {
	private String area;
	private String assignedTo;
	
}
