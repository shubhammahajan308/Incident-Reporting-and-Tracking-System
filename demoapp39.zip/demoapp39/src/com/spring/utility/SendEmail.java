package com.spring.utility;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import com.spring.utility.MyQr;

public class SendEmail {
	final static String username = "smm21061996@gmail.com";//set here your system admin user id
    final static String password = "Sm@210696";//set here your system admin password
	public static void sendMail(String maito,String mailsubject,String bodyMessage)
	{

        

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "465");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.socketFactory.port", "465");
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("smm21061996@gmail.com","System Admin"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(maito)
            );
            message.setSubject(mailsubject);
            String msgtemp=bodyMessage+"<br><br>/****<i>This is System Generated Mail, Kindly do not reply...!!</i>****/";
            message.setText(msgtemp);

            Transport.send(message);

            System.out.println("Done");

        } catch (MessagingException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	public static void sendActivationMail(String custmrmail,String otp)
	{

        

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "465");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.socketFactory.port", "465");
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("smm21061996@gmail.com","System Admin"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse("rushipund117@gmail.com")
                   
            );
            
            message.setSubject("Activation Code for User Admin");
            String msgtemp="Dear Suport Team,<br><br>"+
            		"An user with  username <b>"+custmrmail+"</b> has registered as System Admin..<br>"+
            		"Kindy provide him Activation OTP <b>"+otp+"</b><br><br>"+
            "<br><br>/****<i>This is System Generated Mail, Kindly do not reply...!!</i>****/";
            message.setContent(msgtemp, "text/html");

            Transport.send(message);

            System.out.println("Done");

        } catch (MessagingException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	public static void sendActivationOTP(String custmrmail,String otp)
	{

        

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "465");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.socketFactory.port", "465");
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("smm21061996@gmail.com","System Admin"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(custmrmail)
                   
            );
            message.setSubject("Activation Code for User Admin");
            String msgtemp="Dear User,<br><br>"+
            		"Your Activation OTP is <b>"+otp+"</b><br><br>"+
            "<br><br>/****<i>This is System Generated Mail, Kindly do not reply...!!</i>****/";
            message.setContent(msgtemp, "text/html");

            Transport.send(message);

            System.out.println("Done");

        } catch (MessagingException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	public static void sendOTPVerifyMail(String custmrmail,String verificationurl)
	{

        

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "465");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.socketFactory.port", "465");
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("smm21061996@gmail.com","System Admin"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(custmrmail)
                   
            );
            message.setSubject("OTP verification Link for Admin Registartion");
            String msgtemp="Dear User,<br><br>"+
            		"Your OTP verification Link is <b>"+verificationurl+"</b><br><br>"+
            		"Click On link to verify OTP's Or copy Link on browser with Active session.<br>"+
            		"Remeber ..Do not use tampered link..<br>"+
            "<br><br>/****<i>This is System Generated Mail, Kindly do not reply...!!</i>****/";
            message.setContent(msgtemp, "text/html");

            Transport.send(message);

            System.out.println("Done");

        } catch (MessagingException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	public static void sendSetpasswordLink(String custmrmail,String url)
	{

        try
        {
        	Properties prop = new Properties();
            prop.put("mail.smtp.host", "smtp.gmail.com");
            prop.put("mail.smtp.port", "465");
            prop.put("mail.smtp.auth", "true");
            prop.put("mail.smtp.socketFactory.port", "465");
            prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            
            Session session = Session.getInstance(prop,
                    new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(username, password);
                        }
                    });

            try {

                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress("smm21061996@gmail.com","System Admin"));
                message.setRecipients(
                        Message.RecipientType.TO,
                        InternetAddress.parse(custmrmail)
                );
                message.setSubject("Password Updation..");
	            MimeMultipart multipart = new MimeMultipart("related");
	            BodyPart messageBodyPart = new MimeBodyPart();
                String msgtemp="Dear User,<br><br>"+
                		"<i>Congratulations..! </i><br>"+
                		"You are successfully registered with System.. Kindly follow link Else Scan QR-Code to set your login password..<br><br>"+
                		""+url+"<br><br>"+
                		"<img src=\"cid:image\">"+
                		"Remeber ..Do not use tampered link..<br>"+
                "<br><br>/****<i>This is System Generated Mail, Kindly do not reply...!!</i>****/";
                messageBodyPart.setContent(msgtemp, "text/html");
                multipart.addBodyPart(messageBodyPart);
                String base64Image=MyQr.getQR(url);
	            byte[] rawImage = Base64.getDecoder().decode(base64Image);
	            messageBodyPart = new MimeBodyPart();
	            ByteArrayDataSource imageDataSource = new ByteArrayDataSource(rawImage,"image/png");
	            messageBodyPart.setDataHandler(new DataHandler(imageDataSource));
	            messageBodyPart.setHeader("Content-ID", "<image>");
	            multipart.addBodyPart(messageBodyPart);
	            message.setContent(multipart);
             
                Transport.send(message);

                System.out.println("Done");

            } catch (MessagingException e) {
                e.printStackTrace();
            }	
        }
        catch(Exception ee)
        {
        	System.out.println("Erro is "+ee.getStackTrace());
        }

        
	}
}
