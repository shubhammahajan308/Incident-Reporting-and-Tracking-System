package com.spring.utility;

import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Base64;

public class GenerateRandomNumbers {

	public static String randomnum(char prefix)
	{
	      Random rand = new Random();
        int rand_int1= rand.nextInt(1000000);
        return prefix+"-"+rand_int1;
	} 
	public boolean isValidEmail(String emailid)
	{
		 
		String regex = "^(.+)@(.+)$";
		 
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(emailid);
	   return matcher.matches();
	}
	public static String customEncode(String strinp)
	{
		String originalInput = strinp;
		Base64 base64 = new Base64();
		String str = new String(base64.encode(originalInput.getBytes()));
		 StringBuffer sb = new StringBuffer();
		 char ch[] = str.toCharArray();
	      for(int i = 0; i < ch.length; i++) {
	         String hexString = Integer.toHexString(ch[i]);
	         sb.append(hexString);
	      }
	      String result = sb.toString();
	      return result;
	}
	public static String customDecode(String str)
	{
		String result = new String();
	      char[] charArray = str.toCharArray();
	      for(int i = 0; i < charArray.length; i=i+2) {
	         String st = ""+charArray[i]+""+charArray[i+1];
	         char ch = (char)Integer.parseInt(st, 16);
	         result = result + ch;
	      }
	    
	      String decodedString = new String(Base64.decodeBase64(result.getBytes()));
	      return decodedString;
	}
}
