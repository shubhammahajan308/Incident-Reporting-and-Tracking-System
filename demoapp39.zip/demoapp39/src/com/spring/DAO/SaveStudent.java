package com.spring.DAO;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hibernate.StudentDAO;
import com.spring.Student;
import com.spring.dto.Complaint;

public class SaveStudent {

	public String saveData(Student ss)
	{
ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
StudentDAO studdao = context.getBean(StudentDAO.class);
	
studdao.save(ss);
		
		System.out.println("Person::"+ss);
		
		List<Complaint> list = studdao.list();
		
		for(Complaint p : list){
			System.out.println("Person List::"+p);
		}
		context.close();	
		return "";
	}
}
