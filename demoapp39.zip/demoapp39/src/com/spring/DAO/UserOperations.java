package com.spring.DAO;

import com.hibernate.StudentDAOImpl;
import com.spring.model.User;
import com.spring.service.*;

public class UserOperations {
	
	int saveUser(User u)
	{
		StudentDAOImpl imp=new StudentDAOImpl();
		int res=imp.save(u);
		return res;
	}

}
