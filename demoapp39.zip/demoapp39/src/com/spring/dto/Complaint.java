package com.spring.dto;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.spring.model.User;

@Entity
@Table
public class Complaint {
  
	
	@Id
	@GeneratedValue
	private int incidentId;
	
	private String date;
	private String area;
	private String latitude;
	private String longitude;
	private String status;
	private String complaintDesc;
	private String image;
	private String isActive;	
	
	@ManyToOne
	@JoinColumn(name="id",nullable=true)
	private User user;
	
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Complaint(String date, String area, String complaintDesc) {
		super();
		this.date = date;
		this.area = area;
		this.complaintDesc = complaintDesc;
	}
	
	
	public Complaint() {
		super();
		
	}
	public int getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(int incidentId) {
		this.incidentId = incidentId;
	}
	
	
	
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getComplaintDesc() {
		return complaintDesc;
	}
	public void setComplaintDesc(String complaintDesc) {
		this.complaintDesc = complaintDesc;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	
	
	
	@Override
	public String toString() {
		return "Complaint [incidentId=" + incidentId +  ", date=" + date + ", area=" + area
				+ ", latitude=" + latitude + ", longitude=" + longitude + ", status=" + status + ", complaintDesc="
				+ complaintDesc + ", image=" + image + "]";
	}
	
	
	 
	
	
	
	
}
