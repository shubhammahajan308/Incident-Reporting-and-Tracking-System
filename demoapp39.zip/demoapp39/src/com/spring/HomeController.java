package com.spring;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.hibernate.StudentDAOImpl;
import com.spring.dto.Complaint;
import com.spring.model.User;
import com.spring.service.CreateApprovalForAdmin;
import com.spring.service.UserOperations;
import com.spring.utility.GenerateRandomNumbers;

@Controller
public class HomeController {
	StudentDAOImpl impl=new StudentDAOImpl();
	@RequestMapping("/") 
	public String home(){
	    return "login"; 
	} 
	
	
	@RequestMapping("/homepage") 
	public String homepage(){
	    return "homepage"; 
	} 
	@RequestMapping("/homeforregister")
	public String homeforregister()
	{
		return "home";
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
	

		return "register";
	}
	
	
	
	@RequestMapping("/welcome")
	public ModelAndView helloWorld() {
 
		String message = "<br><div style='text-align:center;'>"
				+ "<h3>********** Hello World, Spring MVC Tutorial</h3>This message is coming from CrunchifyHelloWorld.java **********</div><br><br>";
		return new ModelAndView("welcome", "message", message);
	}
	
	
	
	  @RequestMapping(value="/verifyadminotp",method = RequestMethod.POST)
	  @ResponseBody
	  public String handlePostRequest(String firstName, String lastName) {
	      return String.format("simple response. name: %s, address: %s",
	    		  firstName, lastName);
	  }
	  
	  
	  
	  @RequestMapping(value="/newregister",method = RequestMethod.POST)
	  public ModelAndView registernew(@RequestBody MultiValueMap<String, String> queryParameters) {
		  
	            
		  Map<String,String> map = new HashMap<String,String>();

		   Iterator<String> it = queryParameters.keySet().iterator();


		         while(it.hasNext()){
		           String theKey = (String)it.next();
		           map.put(theKey,queryParameters.getFirst(theKey));
		       }
		        System.out.println( map.get("firstName"));
		        System.out.println( map.get("lastName"));
		        System.out.println( map.get("role"));
		        System.out.println( map.get("phoneNumber"));
		        System.out.println( map.get("gender"));
		        System.out.println( map.get("birthDate"));
		        System.out.println( map.get("email"));
		        System.out.println(map.get("area"));
		        System.out.println( map.get("baseurl"));
		        if(map.get("firstName").equals("")||map.get("lastName").equals("")||map.get("role").equals("")||map.get("phoneNumber").equals("")||map.get("gender")==null||map.get("birthDate").equals("")||map.get("email").equals("")|| map.get("area").equals("")) {
		        	 String message = "All fieds are mandatory..";
						return new ModelAndView("register", "warnmessage", message);
		        }
		        else
		        {
		        	User u=new User();
		        	u.setFirstName(map.get("firstName"));
		        	u.setLastName(map.get("lastName"));
		        	u.setRole(map.get("role"));
		        	u.setPhoneNumber(map.get("phoneNumber"));
		        	u.setGender(map.get("gender"));
		        	u.setEmail(map.get("email"));
		        	 u.setArea(map.get("area"));
		        	SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-MM-DD");  
		        	
		        	try {
						u.setBirthDate(formatter1.parse(map.get("birthDate")));
					} catch (ParseException e) {
						
						e.printStackTrace();
					}
		        	
		        	if(map.get("role").toString().equalsIgnoreCase("Admin"))
		        	{
			        		if(CreateApprovalForAdmin.isAdminExist(u))
			        		{
			        			String message = "<br><div style='text-align:center;'>"
										+ "<h3>Only One Admin is allowed in System..Someone already registerd as Admin..!.</h3></div><br><br>";
					        	
									return new ModelAndView("Message", "message", message);
			        		}
			        		else
			        		{
			        				if(CreateApprovalForAdmin.CreateApprovalRecord(u))
			        				{
			        					
			        					String message = "<br><div style='text-align:center;'>"
												+ "<h3>Kindly Check Your Email Inbox to complete Registration Process..! Kindly Contact Development team to Get Activation Code..!</h3></div><br><br>";
							        	
											return new ModelAndView("Message", "message", message);
			        				}
			        				else
			        				{
			        					String message = "<br><div style='text-align:center;'>"
												+ "<h3>Errror Occured..Kindly Contact Support Team...</h3></div><br><br>";
							        	
											return new ModelAndView("Message", "message", message);
			        				}
			        			
			        		}
		        	}
		        	else
		        	{
		        		if(UserOperations.saveUser(u)>0)
		        		{
		        			String email=map.get("email").toString();
			        		UserOperations.sendSetPasswordLink(GenerateRandomNumbers.customEncode(email),map.get("baseurl").toString());
			        		String message = "<br><div style='text-align:center;'>"
									+ "<h3>Kindly Check Your Email Inbox to complete Registration Process..</h3></div><br><br>";
				        	
								return new ModelAndView("Message1", "message", message);
		        		}
		        		else
		        		{
		        			String message = "<br><div style='text-align:center;font-size:30px;color:red;'>"
									+ "<h3>Already Registerd Email...Enter different Email....</h3></div><br><br>";
				        	
								return new ModelAndView("Message", "message", message);
		        		}
		        		
		        	
		        	}
		        	
		  
		        
		        }
	       
	        
		  
	  }
	  
	  
	  @RequestMapping(value="/verifyttotp",method=RequestMethod.GET)
	  public ModelAndView handleget(@RequestParam("token") String token,Model map) 
	  {
		 
		 try
		 {
			
			  if(token==""||token==null)
			 {
				 String message = "<br><div style='text-align:center;'>"
							+ "<h3>Invalid Url...</h3></div><br><br>";
					return new ModelAndView("Message", "message", message);
			 }
			  else
			  {
				  String decodedmail=GenerateRandomNumbers.customDecode(token);
				  boolean isvalidmail=new GenerateRandomNumbers().isValidEmail(decodedmail);
				  if(isvalidmail)
				  {
					  
					//  ref.addObject("secret", token);
					  return new ModelAndView("otpverify", "message", token );
				  }
				  else
				  {
					  String message = "<br><div style='text-align:center;'>"
								+ "<h3>Invalid token provided...</h3></div><br><br>";
						return new ModelAndView("Message", "message", message);
				  }
				 
			  }
			
			 
		 }
		 catch(Exception ee)
		 {
			 String message = "<br><div style='text-align:center;'>"
						+ "<h3>TEchnical Error ..Kindly vontact support team...</h3></div><br><br>";
				return new ModelAndView("Message", "message", message);
		 }
		
	  }
	  @RequestMapping(value="/emailotpverify",method = RequestMethod.POST)
	  public ModelAndView emailotpverifyfunc(@RequestBody MultiValueMap<String, String> queryParameters)
	  {
		  ModelAndView ref=new ModelAndView();
		
			  Map<String,String> map = new HashMap<String,String>();

			   Iterator<String> it = queryParameters.keySet().iterator();


			         while(it.hasNext()){
			           String theKey = (String)it.next();
			           map.put(theKey,queryParameters.getFirst(theKey));
			       }
		 
			         String token=map.get("token");
		  if(map.get("selfotp").isBlank()||map.get("aotp").isBlank()|map.get("token").isBlank())
		  {
			  ref.addObject("message", token);
			  ref.addObject("errormessage", "Fields cant be blank..!");
			  ref.setViewName("otpverify");
		  }
		  else
		  {
			  String self=map.get("selfotp");
			  String activateotp=map.get("aotp");
			 
			  if(UserOperations.verifyAdminOTP(self, activateotp, token))
			  {
				  if(UserOperations.activateuser(token))
				  {
					  UserOperations.sendSetPasswordLink(token,map.get("baseurl").toString());
					  ref.addObject("message", token);
					  ref.addObject("errormessage", "");
					  ref.addObject("successmessage", "OTP verification Successful..!! Check your Email to Set Password");
					  ref.setViewName("otpverify");
				  }
				  else
				  {
					  ref.addObject("message", token);
					  ref.addObject("errormessage", "OTP verification Failed....!!");
					  ref.addObject("successmessage", "");
					  ref.setViewName("otpverify");
				  }
			  }
			  else
			  {
				  ref.addObject("message", token);
				  ref.addObject("errormessage", "OTP is not vaild....!!");
				  ref.addObject("successmessage", "");
				  ref.setViewName("otpverify");
			  }
			 
		  }
			return ref;
		  
	  }
	  @RequestMapping(value="/setpassword",method=RequestMethod.GET)
	  public ModelAndView setPassword(@RequestParam("token") String token,Model map) 
	  {
		 
		 try
		 {
			
			  if(token==""||token==null)
			 {
				 String message = "<br><div style='text-align:center;'>"
							+ "<h3>Invalid Url...</h3></div><br><br>";
					return new ModelAndView("Message", "message", message);
			 }
			  else
			  {
				  String decodedmail=GenerateRandomNumbers.customDecode(token);
				  boolean isvalidmail=new GenerateRandomNumbers().isValidEmail(decodedmail);
				  if(isvalidmail)
				  {
					  
					//  ref.addObject("secret", token);
					  return new ModelAndView("setpassword", "message", token );
				  }
				  else
				  {
					  String message = "<br><div style='text-align:center;'>"
								+ "<h3>Invalid token provided...</h3></div><br><br>";
						return new ModelAndView("Message", "message", message);
				  }
				 
			  }
			
			 
		 }
		 catch(Exception ee)
		 {
			 String message = "<br><div style='text-align:center;'>"
						+ "<h3>TEchnical Error ..Kindly vontact support team...</h3></div><br><br>";
				return new ModelAndView("Message", "message", message);
		 }
		
	  }

	  @RequestMapping(value="/passwordupdate",method=RequestMethod.POST)
	  public ModelAndView updatePassword(@RequestBody MultiValueMap<String, String> queryParameters) 
	  {
		 
		  ModelAndView ref=new ModelAndView();
			
		  Map<String,String> map = new HashMap<String,String>();

		   Iterator<String> it = queryParameters.keySet().iterator();


		         while(it.hasNext()){
		           String theKey = (String)it.next();
		           map.put(theKey,queryParameters.getFirst(theKey));
		       }
	 
		         String token=map.get("token");
	  if(map.get("password1").isBlank()||map.get("password2").isBlank()|map.get("token").isBlank())
	  {
		  ref.addObject("message", token);
		  ref.addObject("errormessage", "Fields cant be blank..!");
		  ref.setViewName("setpassword");
	  }
        else if(map.get("password1").length()<6 && map.get("password2").length()<6) {
        	 ref.addObject("message", token);
   		     ref.addObject("errormessage", "Password must be more than 6 characters!");
   		     ref.setViewName("setpassword");  
	  }
	  else if(!map.get("password1").equals(map.get("password2")))
	  {
		  ref.addObject("message", token);
		  ref.addObject("errormessage", "Password doesnt match..!");
		  ref.setViewName("setpassword");
	  }
	  
	  else
	  {
		  String password=map.get("password1");
		  
		 
		  if(UserOperations.updateOrCreateUserAuth(password, token))
		  {
			  ref.addObject("message", token);
			  ref.addObject("errormessage", "");
			  ref.addObject("successmessage", "Password Updated Successfully..!!");
			  ref.setViewName("setpassword");
		  }
		  else
		  {
			  ref.addObject("message", token);
			  ref.addObject("errormessage", "Password Updation Failed....!!");
			  ref.addObject("successmessage", "");
			  ref.setViewName("setpassword");
		  }
		 
	  }
		return ref;
	  
	  }
	  
	  
	  @RequestMapping(value="/loginuser",method=RequestMethod.POST)
	  public ModelAndView login(@RequestBody MultiValueMap<String, String> queryParameters,HttpSession session) 
	  {
		 
		  ModelAndView ref=new ModelAndView();
		  	
		  Map<String,String> map = new HashMap<String,String>();
         
		   Iterator<String> it = queryParameters.keySet().iterator();
		         while(it.hasNext()){
		           String theKey = (String)it.next();
		           System.out.println(theKey);
		           map.put(theKey,queryParameters.getFirst(theKey));
		       }  
		         
		    if(map.get("user").isBlank()||map.get("pass").isBlank())
		   	  {
		   		  ref.addObject("error", "Fields cant be blank..!");
		   		  ref.setViewName("login");
		   	  }
		    else
		    {
		    	
		    	if(UserOperations.isValidCreds(map.get("user").toString(),map.get("pass").toString()))
		    	{
		    		User userObj=impl.getUserObject(map.get("user"));
		    		session.setAttribute("user", userObj);
		    		String role=userObj.getRole();
		    		if(role.equalsIgnoreCase("citizen"))
		    		{
		    			ref.setViewName("citizenHome");
		    		}
		    		else if(role.equalsIgnoreCase("admin"))
		    		{
		    			ref.setViewName("adminHome");
		    		}
		    		else if(role.equalsIgnoreCase("wardOfficer"))
		    		{
		    			ref.setViewName("wardOfficerHome");
		    		}
		    		else if(role.equalsIgnoreCase("Commissioner"))
		    		{
		    			ref.setViewName("commissionerHome");
		    		}
		    			
		    	}
		    	else
		    	{
		    		ref.addObject("error", "Invalid Credentials.!");
			   		  ref.setViewName("login");
		    	}
		    }
				return ref;
	  }
	  
	  @RequestMapping(value="/loginuser",method=RequestMethod.GET)
	  public String errorPage1()
	  {
		  return "errorPage";
	  }
	  
	  @RequestMapping(value="/login",method=RequestMethod.GET)
	  public String loadoginpage(Locale locale, Model model) 
	  {
		 return "login";
		 
	  }
	  
	  
	  
	  @RequestMapping(value="/errorPage",method=RequestMethod.GET)
	  public String errorPage()
	  {
		  return "errorPage";
	  }
	  
	  
 

}
