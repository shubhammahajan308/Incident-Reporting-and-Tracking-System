package com.spring;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.spring.daoo.AdminAcceptDaoImple;
import com.spring.daoo.CommissionerDaoImple;
import com.spring.daoo.UserDaoImple;
import com.spring.dto.Complaint;
import com.spring.model.User;

@Controller
public class UserController {
      
	UserDaoImple userImpl=new UserDaoImple();
	CommissionerDaoImple comm=new CommissionerDaoImple();
	AdminAcceptDaoImple accp=new AdminAcceptDaoImple();
	
	@RequestMapping(value = "/complaintForm") 
	public String ComplaintForm(ModelMap map){
	  map.put("compReg", new Complaint());
	    return "complaint"; 
	} 
	 @RequestMapping(value="/updateForm")
	  public String updatingForm()
	  {
		 return "updateForm"; 
		  
	  }
	  
	  
	  @RequestMapping(value="/updatingUser",method = RequestMethod.POST)
	  public ModelAndView updateForm(@RequestBody MultiValueMap<String, String> queryParameters,HttpSession session )
	  {
		  Map<String,String> map = new HashMap<String,String>();

		   Iterator<String> it = queryParameters.keySet().iterator();
		   while(it.hasNext()){
	           String theKey = (String)it.next();
	           map.put(theKey,queryParameters.getFirst(theKey));
	       }
		   User user=new User();
		user.setId(Integer.parseInt(map.get("id")));
	   	user.setFirstName(map.get("firstName"));
	   	user.setLastName(map.get("lastName"));
	   	user.setPhoneNumber(map.get("phoneNumber"));
	   	user.setArea(map.get("area"));
		 String message ;
	    if(user.getArea().equals("")||user.getFirstName().equals("")||user.getLastName().equals("")||user.getPhoneNumber().equals("")) {
	     	  message = "<h3 style='color:red;'>All fields are mandatory</h3>";
	    }
	    else {	
		   userImpl.updateForm(user);
		   
		   message = "<h3 style='color:palegreen;'>Your Profile Updated Successfully..</h3>";
	    }
	    return new ModelAndView("updateForm", "warnmessage", message);
	  }
  
  @RequestMapping(value = "/imageUpload" ,method=RequestMethod.POST)
  public ModelAndView RegisterComplaint(@RequestParam("image") MultipartFile file,@RequestParam String area,
		  @RequestParam String date,@RequestParam String complaintDesc,HttpSession session,HttpServletRequest request)
  {
	  if(area.equals("")||date.equals("")||complaintDesc.equals("")) {
     	 String message = "All fieds are mandatory..";
				return new ModelAndView("complaint", "warnmessage", message);
     }
	  else {
	  Complaint compl=new Complaint(date,area,complaintDesc);
	  String fileName = "0";
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				
				fileName = file.getOriginalFilename();
				fileName = fileName.substring(fileName.lastIndexOf("."));
				System.out.println(fileName);	
				
				fileName = "1"+fileName;
				String rootPath = request.getServletContext().getRealPath("/");
				File dir = new File(rootPath + File.separator + "photos");
				if (!dir.exists())
					dir.mkdirs();			
				String filePath = dir.getAbsolutePath()+ File.separator +fileName;
				
				
				System.out.println("Server File Location= "+ filePath );
				
				File serverFile = new File(filePath);
				
						
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				compl.setImage(fileName);
				

			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
	  
	  User user=(User)session.getAttribute("user");
	 System.out.println(user.getId());
	 compl.setUser(user);
	 compl.setStatus("pending");
	 compl.setIsActive("false");
	  userImpl.ComplaintRegister(compl); 
	  return new ModelAndView("successComplaint");

  }
  }
  
  @RequestMapping(value="/checkStatus",method=RequestMethod.GET)
  public String checkStatus(@RequestParam String area,ModelMap map)
  {
	  System.out.println(area);
	  List<Complaint> li=userImpl.checkStatus(area);
	  map.put("Commlist", li);
	  return "checkStatus";
  }
  @RequestMapping(value = "/logout")
  public String logout(HttpSession session) {
	  session.removeAttribute("user");
	      return "login";
	  }
  @RequestMapping(value = "/citizenHome")
  public String homepage() {
	  
	      return "citizenHome";
	  }
  @RequestMapping(value="/imageViewCitizen",method=RequestMethod.GET)
  public String ShowImageComm(@RequestParam int incidentId,ModelMap map)
  {
	  		  Complaint comp=accp.showImage(incidentId);
	          map.put("comp", comp);
	  return "imageViewCitizen";
  }
  @RequestMapping(value="/CitizenListBack",method=RequestMethod.GET)
	 public String backCitizenButton(@RequestParam String area,ModelMap map)
	 {
	  List<Complaint> li=userImpl.checkStatus(area);
	  map.put("Commlist", li);
	  return "checkStatus";
		
	 }
  
}
