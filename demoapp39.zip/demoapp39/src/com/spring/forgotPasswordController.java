package com.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.daoo.ForgotPasswordDaoImple;
import com.spring.daoo.UserDaoImple;
@Controller
public class forgotPasswordController {
     @Autowired
	ForgotPasswordDaoImple forImple;
     @Autowired
 	private MailSender mailSender;
	
	 @RequestMapping(value = "/forgot_player_password.htm",method = RequestMethod.POST)
		public String forgotPassword(@RequestParam String email,ModelMap map) {		
			String pass = forImple.forgotPassword(email);
			String baseUrl="http://localhost:8080/demoapp/spring/login";
			String msg = "you are not registered";
			if(pass!=null) {	
				SimpleMailMessage message = new SimpleMailMessage();  
		        message.setFrom("finalprojectteam25@gmail.com");  
		        message.setTo(email);  
		        message.setSubject("Your password");  
		        message.setText(baseUrl+"  "+"Your Password is "+ pass);  
		        mailSender.send(message);
				msg = "check the mail for password";
			}
			map.put("msg", msg);
			return "forgotSuccess";
		}
	 @RequestMapping(value = "/ForgotPasswordPage")
	 public String ForgotPage()
	 {
		 return "ForgotPassword";
	 }
	 
	 
	
	
}