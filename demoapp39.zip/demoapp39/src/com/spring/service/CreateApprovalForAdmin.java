package com.spring.service;

import com.spring.daoo.AdminDaoImple;
import com.spring.model.ActivationMaster;
import com.spring.model.User;
import com.spring.utility.GenerateRandomNumbers;
import com.spring.utility.SendEmail;
import com.spring.service.*;

import java.util.List;

import com.hibernate.*;;

public class CreateApprovalForAdmin {
	
	public static boolean isAdminExist(User user)
	{
		boolean flag=false;
		String usermail=user.getEmail();
			StudentDAOImpl impl=new StudentDAOImpl();
			try
			{
				List<ActivationMaster> list=impl.listAdmin();
				if(list.size()>0)
				{
					  for (ActivationMaster master : list) 
					  {
						  if(master.isVerified()=='Y')
							{
							
								flag= true;
								break;
								
							}
							else
							{
								flag=false;
							}
				        }
					
					
					
				}
				else
				{
					flag= false;
				}
				
				
			}
			catch(Exception ee)
			{
				flag=false;
			}
	return flag;
		
		
	}
	
	public static boolean CreateApprovalRecord(User user)
	{
		
		ActivationMaster master=new ActivationMaster();
		master.setEmail(user.getEmail());
		String sefotp=GenerateRandomNumbers.randomnum('A');
		String actotp=GenerateRandomNumbers.randomnum('B');
		SendEmail.sendActivationMail(user.getEmail(), actotp);
		SendEmail.sendActivationOTP(user.getEmail(), sefotp);
		master.setSelfOTP(sefotp);
		master.setActivationOTP(actotp);
		master.setVerified('N');
		 String encodedemail=GenerateRandomNumbers.customEncode(user.getEmail());
		String urltemp="http://localhost:8080/demoapp/spring/verifyttotp?token="+encodedemail+"";
		
		
		
		try
		{
			String res=UserOperations.saveActivationMaster(master);
			if(res=="success")
			{
				if(UserOperations.saveUser(user)>0)
				{
					SendEmail.sendOTPVerifyMail(user.getEmail(), urltemp);
					return true;
				}
				else
				{
					return false;
				}
					
				
				
			}
			{
				return false;
			}
				
			
			
		}
		catch(Exception ee)
		{
			
			System.out.println(ee);
			return false;
		}
		
		
		//return false;
		
	}
	
	
	
	public static boolean isCommisonerExist(User user)
	{
		boolean flag=false;
		String usermail=user.getEmail();
		    AdminDaoImple adm=new AdminDaoImple();
			
			try
			{
				List<User> list= adm.listCommissioner();
				if(list.size()>0)
				{
					  return true;
				}
				else
				{
					return false;
				}
		
			}
			catch(Exception ee)
			{
				  flag=false;
			}
	    return flag;
		
		
	}

}
