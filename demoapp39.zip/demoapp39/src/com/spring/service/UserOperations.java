package com.spring.service;

import java.util.Date;
import java.util.List;

import com.hibernate.StudentDAOImpl;
import com.spring.daoo.UserDaoImple;
import com.spring.model.ActivationMaster;
import com.spring.model.AuthenticationData;
import com.spring.model.User;
import com.spring.utility.GenerateRandomNumbers;
import com.spring.utility.SendEmail;

public class UserOperations {
	
	
	private UserDaoImple imple;
	public static int saveUser(User std)
	{
		Date d=new Date();
		
		String id=d.getDate()+""+d.getMonth()+1+""+d.getYear()+""+d.getHours()+""+d.getMinutes()+""+d.getSeconds();
		
		
		
		std.setUniqueId("USID"+id);
		StudentDAOImpl imp=new StudentDAOImpl();
		int temp=imp.save(std);
		return temp;
	}
	public static int saveAuth(AuthenticationData std)
	{
		
		StudentDAOImpl imp=new StudentDAOImpl();
		int temp=imp.save(std);
		return temp;
	}
	public static String saveActivationMaster(ActivationMaster std)
	{
		
		StudentDAOImpl imp=new StudentDAOImpl();
		String temp=imp.save(std);
		return temp;
	}
	public static boolean verifyAdminOTP(String self,String activateotp,String token)
	{
		boolean flag=false;
		String Decodedemail=GenerateRandomNumbers.customDecode(token);
		StudentDAOImpl imp=new StudentDAOImpl();
		List<ActivationMaster> list=imp.adminByEmail(Decodedemail);
		 for (ActivationMaster master : list) 
		 {
			 if(master.getSelfOTP().equals(self)&&master.getActivationOTP().equals(activateotp))
			 {
				 flag=true;
				 break;
			 }
		 }
		return flag;
	}
	public static boolean activateuser(String token)
	{
		boolean flag=false;
		String Decodedemail=GenerateRandomNumbers.customDecode(token);
		StudentDAOImpl imp=new StudentDAOImpl();
		int count=imp.activateUser(Decodedemail);
		if(count>0)
			flag=true;
		else
			flag=false;
		
		System.out.println("User Activated: "+count);
		return flag;
	}
	public static boolean updateOrCreateUserAuth(String password, String token)
{
		AuthenticationData auth=new AuthenticationData();
		
		auth.setEmail(GenerateRandomNumbers.customDecode(token));
		auth.setAuthString(GenerateRandomNumbers.customEncode(password));
		auth.setActive(true);
		StudentDAOImpl imp=new StudentDAOImpl();
		if(imp.authByEmail(GenerateRandomNumbers.customDecode(token)).size()>0)
		{
			System.out.print("InUpdate");
			if(imp.update(auth)>0)
				return true;
			else
				return false;
		}
		else
		{
			System.out.print("In Create");
			if(imp.save(auth)>0)
				return true;
			else
				return false;
			
		}
		
	}
	public static void sendSetPasswordLink(String token,String baseur)
	{
		System.out.print(baseur);
		String email=GenerateRandomNumbers.customDecode(token);
		String urltemp=baseur+"/demoapp/spring/setpassword?token="+token+"";
		System.out.print(baseur);
		SendEmail.sendSetpasswordLink(email, urltemp);
		
	}
	public static  boolean isValidCreds(String uname,String pass) {
		StudentDAOImpl imp=new StudentDAOImpl();
		List<AuthenticationData> list=imp.authByEmail(uname);
		if(list.isEmpty()) {
			return  false;
		}
		else if(pass.equals(GenerateRandomNumbers.customDecode(list.get(0).getAuthString())))
		{
			
			
			return true;
		}
		else
		{
			return false;
		}
		
		
	}
}
