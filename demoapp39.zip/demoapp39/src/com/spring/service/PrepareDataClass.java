package com.spring.service;

import java.util.Date;
import java.util.List;

import com.hibernate.StudentDAOImpl;
import com.spring.Student;
import com.spring.dto.Complaint;

public class PrepareDataClass {

	public static int saveUser(Student std)
	{
		Date d=new Date();
		
		String id=d.getDate()+""+d.getMonth()+1+""+d.getYear()+""+d.getHours()+""+d.getMinutes()+""+d.getSeconds();
		
		
		
		std.setUniqueID("USID"+id);
		StudentDAOImpl imp=new StudentDAOImpl();
		int temp=imp.save(std);
		return temp;
	}
	public static List<Complaint> getStudents(){
		StudentDAOImpl imp=new StudentDAOImpl();
		return imp.list();
	}
	public static List<Complaint> getCasesByStatus(String id) {
		StudentDAOImpl imp=new StudentDAOImpl();
		return imp.CaseListByStatus(id);
	}
	
}
