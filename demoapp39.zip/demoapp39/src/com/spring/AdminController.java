package com.spring;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.daoo.AdminAcceptDaoImple;
import com.spring.daoo.AdminDaoImple;
import com.spring.dto.Complaint;
import com.spring.model.User;
import com.spring.service.CreateApprovalForAdmin;
import com.spring.service.UserOperations;
import com.spring.utility.GenerateRandomNumbers;

@Controller
public class AdminController {
      
	  AdminDaoImple adm=new AdminDaoImple();
	  AdminAcceptDaoImple accp=new AdminAcceptDaoImple();
	  @RequestMapping(value="/AdComplaintList",method=RequestMethod.GET)
	  public String showComplaintList(ModelMap map)
	  {
		  List<Complaint> li=adm.showComplaintList();
		  map.put("Clist", li);
		  return "AdComplaintList";
	  }
	  
	  
	  @RequestMapping(value="/approve",method=RequestMethod.GET)
	  public String ApproveComplaint(@RequestParam int incidentId,ModelMap map)
	  {
		  accp.updateIsActiveStatus(incidentId);
		  List<Complaint> li=adm.showComplaintList();
		  map.put("Clist", li);
		  return "AdComplaintList";
	  }
	  
	  @RequestMapping(value="/imageView",method=RequestMethod.GET)
	  public String ShowImage(@RequestParam int incidentId,ModelMap map)
	  {
		  		  Complaint comp=accp.showImage(incidentId);
                  System.out.println(comp.getArea());
                  System.out.println(comp.getComplaintDesc());
		          map.put("comp", comp);
		  return "imageView";
	  }
	  
	  
	  
	  @RequestMapping(value="/reject",method=RequestMethod.GET)
	  public String rejectComplaint(@RequestParam int incidentId,ModelMap map)
	  {
		  accp.rejectedComplaint(incidentId);
		  List<Complaint> li=adm.showComplaintList();
		  map.put("Clist", li);
		  return "AdComplaintList";
	  }
	  
	  @RequestMapping(value="/pre_Off_RegForm",method=RequestMethod.GET)
	  public String OfficerRegForm()
	  {
		  
		  return "OffCommReg";
	  }
	  @RequestMapping(value="/adminHome",method=RequestMethod.GET)
	  public String AdminHome()
	  {
		  
		  return "adminHome";
	  }
	  @RequestMapping(value="/adminBack1",method=RequestMethod.GET)
		 public String adminBack1(ModelMap map)
		 {
		  List<Complaint> li=adm.showComplaintList();
		  map.put("Clist", li);
		  return "AdComplaintList";
		 }

	  
	  
	  @RequestMapping(value="/Adminregister",method = RequestMethod.POST)
	  public ModelAndView registernew(@RequestBody MultiValueMap<String, String> queryParameters) {
		  
	            
		  Map<String,String> map = new HashMap<String,String>();

		   Iterator<String> it = queryParameters.keySet().iterator();


		         while(it.hasNext()){
		           String theKey = (String)it.next();
		           map.put(theKey,queryParameters.getFirst(theKey));
		       }
		        System.out.println( map.get("firstName"));
		        System.out.println( map.get("lastName"));
		        System.out.println( map.get("role"));
		        System.out.println( map.get("phoneNumber"));
		        System.out.println( map.get("gender"));
		        System.out.println( map.get("birthDate"));
		        System.out.println( map.get("email"));
		        System.out.println(map.get("area"));
		        System.out.println( map.get("baseurl"));
		        if(map.get("firstName").equals("")||map.get("lastName").equals("")||map.get("role").equals("")||map.get("phoneNumber").equals("")||map.get("gender")==null||map.get("birthDate").equals("")||map.get("email").equals("")|| map.get("area").equals("")) {
		        	 String message = "All fieds are mandatory..";
						return new ModelAndView("register", "warnmessage", message);
		        }
		        else
		        {
		        	User u=new User();
		        	u.setFirstName(map.get("firstName"));
		        	u.setLastName(map.get("lastName"));
		        	u.setRole(map.get("role"));
		        	u.setPhoneNumber(map.get("phoneNumber"));
		        	u.setGender(map.get("gender"));
		        	u.setEmail(map.get("email"));
		        	 u.setArea(map.get("area"));
		        	SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-MM-DD");  
		        	
		        	try {
						u.setBirthDate(formatter1.parse(map.get("birthDate")));
					} catch (ParseException e) {
						
						e.printStackTrace();
					}
		        	
		        	if(map.get("role").toString().equalsIgnoreCase("commissioner"))
		        	{
			        		if(CreateApprovalForAdmin.isCommisonerExist(u))
			        		{
			        			String message = "<br><div style='text-align:center;'>"
										+ "<h3>Only One Commissioner is allowed in System..you already registerd commissioner..!.</h3></div><br><br>";
					        	
									return new ModelAndView("Message", "message", message);
			        		}
			        		else
			        		{
			        			if(UserOperations.saveUser(u)>0)
				        		{
				        			String email=map.get("email").toString();
					        		UserOperations.sendSetPasswordLink(GenerateRandomNumbers.customEncode(email),map.get("baseurl").toString());
					        		String message = "<br><div style='text-align:center;'>"
											+ "<h3>Kindly Check Your Email Inbox to complete Registration Process..</h3></div><br><br>";
						        	
										return new ModelAndView("Message1", "message", message);
				        		}
				        		else
				        		{
				        			String message = "<br><div style='text-align:center;'>"
											+ "<h3>Error While saving user..</h3></div><br><br>";
						        	
										return new ModelAndView("Message", "message", message);
				        		}
			        			
			        		}
		        	}
		        	else
		        	{
		        		if(UserOperations.saveUser(u)>0)
		        		{
		        			String email=map.get("email").toString();
			        		UserOperations.sendSetPasswordLink(GenerateRandomNumbers.customEncode(email),map.get("baseurl").toString());
			        		String message = "<br><div style='text-align:center;'>"
									+ "<h3>Kindly Check Your Email Inbox to complete Registration Process..</h3></div><br><br>";
				        	
								return new ModelAndView("Message1", "message", message);
		        		}
		        		else
		        		{
		        			String message = "<br><div style='text-align:center;'>"
									+ "<h3>Error While saving user..</h3></div><br><br>";
				        	
								return new ModelAndView("Message", "message", message);
		        		}
		        		
		        	
		        	}
		        	
		  
		        
		        }
	       
	        
		  
	  }
}
