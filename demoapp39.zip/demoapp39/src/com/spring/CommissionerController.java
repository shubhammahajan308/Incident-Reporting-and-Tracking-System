package com.spring;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.daoo.AdminAcceptDaoImple;
import com.spring.daoo.CommissionerDaoImple;
import com.spring.dto.Complaint;

@Controller
public class CommissionerController {
   
	  CommissionerDaoImple comm=new CommissionerDaoImple();
	  AdminAcceptDaoImple accp=new AdminAcceptDaoImple();
	 @RequestMapping(value="/CommComplaintList",method=RequestMethod.GET)
	  public String showComplaintList(ModelMap map)
	  {
		  List<Complaint> li=comm.showComplaintList();
		  map.put("Commlist", li);
		  return "CommComplaintList";
	  }
	 
	 @RequestMapping(value="/assignTask",method=RequestMethod.GET)
	 public String assignTaskToOfficer(@RequestParam int incidentId,ModelMap map)
		{
		     comm.assignTask(incidentId);
		     List<Complaint> li=comm.showComplaintList();
			  map.put("Commlist", li);
			  return "CommComplaintList";
		}
	 
	 @RequestMapping(value="/wardComplaintList", method=RequestMethod.GET)
	 public String showWardOfficerComplaintList(@RequestParam String area ,ModelMap map)
	 {
		 
		 List<Complaint> li=comm.showWardComplaintList(area);
		 map.put("wardlist", li);
		  return "WardComplaintList";
		
	 }
	 
	 @RequestMapping(value="/wardBack",method=RequestMethod.GET)
	 public String backWardButton()
	 {
		 return "wardOfficerHome";
	 }
	 
	 @RequestMapping(value="/WardListBack",method=RequestMethod.GET)
	 public String WardCompBack(@RequestParam String area, ModelMap map)
	 {
		 List<Complaint> li=comm.showWardComplaintList(area);
		 map.put("wardlist", li);
		  return "WardComplaintList";
	 }
	 @RequestMapping(value="/imageViewWard",method=RequestMethod.GET)
	  public String ShowImageWard(@RequestParam int incidentId,ModelMap map)
	  {
		  		  Complaint comp=accp.showImage(incidentId);
		          map.put("comp", comp);
		  return "imageViewWard";
	  }
	 
	 
	 @RequestMapping(value="/completeTask",method=RequestMethod.GET)
	 public String changeCompleteStatus(@RequestParam int incidentId,@RequestParam String area,ModelMap map)
	 {
		 comm.changeCompleteStatus(incidentId);
		 List<Complaint> li=comm.showWardComplaintList(area);
		 map.put("wardlist", li);
		 return "WardComplaintList";
	 }
	 //CommBack
	 
	 @RequestMapping(value="/CommBack",method=RequestMethod.GET)
	 public String backCommButton()
	 {
		 return "commissionerHome";
	 }
	 
	 @RequestMapping(value="/AdminBack",method=RequestMethod.GET)
	 public String backAdminButton()
	 {
		 return "adminHome";
	 }
	 
	 @RequestMapping(value="/CommListBack",method=RequestMethod.GET)
	 public String backCommButton(ModelMap map)
	 {
		 List<Complaint> li=comm.showComplaintList();
		  map.put("Commlist", li);
		  return "CommComplaintList";
		
	 }
	 
	 
	 @RequestMapping(value="/citizenBack",method=RequestMethod.GET)
	 public String citizenback()
	 {
		 return "citizenHome";
	 }
	 @RequestMapping(value="/imageViewComm",method=RequestMethod.GET)
	  public String ShowImageComm(@RequestParam int incidentId,ModelMap map)
	  {
		  		  Complaint comp=accp.showImage(incidentId);
		          map.put("comp", comp);
		  return "imageViewComm";
	  }
	 
		  @RequestMapping("/Complaint_Map") public String Complaint_Map() { 
			  return "openlayers";
		 
		  }
		 
	 
	 
}
