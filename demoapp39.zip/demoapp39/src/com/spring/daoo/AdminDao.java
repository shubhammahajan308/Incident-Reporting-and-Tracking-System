package com.spring.daoo;

import java.util.List;

import com.spring.dto.Complaint;
import com.spring.model.User;

public interface AdminDao {
  
	public List<Complaint> showComplaintList();
	
	public List<User> listCommissioner();
	
}
