package com.spring.daoo;

import java.util.List;

import com.spring.dto.Complaint;
import com.spring.model.User;

public interface UserDao {
     
	public void ComplaintRegister(Complaint complaint);
	public List<Complaint> checkStatus(String area);
	public void updateForm(User user);
	
}
