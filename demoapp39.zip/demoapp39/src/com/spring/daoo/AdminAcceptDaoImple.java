package com.spring.daoo;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.hibernate.HibernateUtil;
import com.spring.dto.Complaint;

@Repository
public class AdminAcceptDaoImple implements AdminAcceptDao{

	private SessionFactory sessionFactory;
	Session session = HibernateUtil.getSessionFactory().openSession();
	Transaction tx;
	
	    public void setSessionFactory(SessionFactory sessionFactory) {
	        this.sessionFactory = sessionFactory;
	    }
	@Override
	public void updateIsActiveStatus(int incidentId) {
		Session sess = HibernateUtil.getSessionFactory().openSession();
		Transaction tx1=sess.beginTransaction();
		 @SuppressWarnings("unchecked")
		Query query=sess.createQuery("update Complaint set isActive=:active where incidentId=:inId");
		query.setParameter("active", "true");
		query.setParameter("inId", incidentId);
		query.executeUpdate();
		tx1.commit();
		sess.close();
		
	}
	@Override
	public void rejectedComplaint(int incidentId) {
		Session sess = HibernateUtil.getSessionFactory().openSession();
		Transaction tx1=sess.beginTransaction();
		 @SuppressWarnings("unchecked")
	    Query query=sess.createQuery("update Complaint set status=:statusFlag where incidentId=:inId");
		 query.setParameter("statusFlag", "rejected");
		 query.setParameter("inId", incidentId);
		query.executeUpdate();
		//now commented **
		tx1.commit();
		//just now added
		sess.close();
		
	}
	@Override
	public List<Complaint> showComplaintList1() {
		
		@SuppressWarnings("unchecked")
		List<Complaint> li=session.createQuery("from Complaint").list();
		
		session.close();
		return li;
		
	}
	public Complaint showImage(int incidentId) {
		Session sess = HibernateUtil.getSessionFactory().openSession();
		sess.beginTransaction();
		String selectQuery = "from Complaint where incidentId=:inId";
		Query query = sess.createQuery(selectQuery);
		query.setParameter("inId", incidentId);
		@SuppressWarnings("unchecked")
		List<Complaint> li=query.list();
		return li.get(0);

	}
	
	

}
