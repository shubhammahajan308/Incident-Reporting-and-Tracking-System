package com.spring.daoo;

public interface ForgotPasswordDao {
    public String forgotPassword(String email);
}
