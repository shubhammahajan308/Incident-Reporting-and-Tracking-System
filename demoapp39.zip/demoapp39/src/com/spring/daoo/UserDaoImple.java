package com.spring.daoo;

import com.spring.dto.Complaint;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;

import com.hibernate.HibernateUtil;
import com.hibernate.StudentDAO;
import com.spring.Student;
import com.spring.model.User;

@Repository
public class UserDaoImple implements UserDao {

	 private SessionFactory sessionFactory;
	 Session session = HibernateUtil.getSessionFactory().openSession();
	 
	 Transaction tx ;
	    public void setSessionFactory(SessionFactory sessionFactory) {
	        this.sessionFactory = sessionFactory;
	    }
	@Override
	public void ComplaintRegister(Complaint complaint) {
		
		Session sess = HibernateUtil.getSessionFactory().openSession();
		Transaction tx1=sess.beginTransaction();
		
		 System.out.println(complaint.getArea());
		sess.save(complaint);
		tx1.commit();
		sess.close();

	}
	@Override
	public void updateForm(User user)
	{
		Session sess = HibernateUtil.getSessionFactory().openSession();
		Transaction tx1=sess.beginTransaction();
		
		 int userId=user.getId();
		 String fName=user.getFirstName();
		 String lName=user.getLastName();
		 String Area=user.getArea();
		
		 String phNo=user.getPhoneNumber();
	
		 String sql="update User set firstName=:fName, lastName=:lName, area = :Area, phoneNumber = :phNo where id = :userId";
		 @SuppressWarnings("unchecked")
		 Query query=sess.createQuery(sql);
		 query.setParameter("fName", fName);
		 query.setParameter("lName", lName);
	
		 query.setParameter("Area", Area);
		
		 query.setParameter("phNo",phNo);
		
		 query.setParameter("userId", userId);
		 query.executeUpdate();

		tx1.commit();

		sess.close();
		
	}
	
	
	@Override
	public List<Complaint> checkStatus(String area) {
		Session sess = HibernateUtil.getSessionFactory().openSession();
		sess.beginTransaction();
		String selectQuery = "from Complaint where area=:idStatus";
		Query query = session.createQuery(selectQuery);
		query.setParameter("idStatus", area);
	  @SuppressWarnings("unchecked")
	   List<Complaint> li=query.list();
		return li;
	}
	
	  public int getIncidentId()
	  {
		  Session sess = HibernateUtil.getSessionFactory().openSession();
			sess.beginTransaction();
			String selectQuery = " from Complaint ORDER BY incidentId desc";
			 Query query = session.createQuery(selectQuery);
			  @SuppressWarnings("unchecked") 
			  List<Complaint> li=query.list(); 
			 
					  Complaint comp=li.get(0);
		int maxId=comp.getIncidentId();
		  return maxId;
	  }
	
	public void shareLocation(String lattitude, String longitude) {
		
		 Session sess = HibernateUtil.getSessionFactory().openSession(); Transaction
		  tx1=sess.beginTransaction();
		 int maxInId=getIncidentId();
		 
		
		String lat=lattitude;
		String lon=longitude;
		System.out.println("*******"+lat+" "+lon+"   "+maxInId);
		 String sql="update Complaint set longitude=:lon, latitude=:lat where incidentId = :maxInId";
		 @SuppressWarnings("unchecked")
		 Query query=sess.createQuery(sql);
		 query.setParameter("lon", lon);
		 query.setParameter("lat", lat);
		 query.setParameter("maxInId", maxInId);
		 query.executeUpdate();
			tx1.commit();
			sess.close();
		
	}
	
	

}
