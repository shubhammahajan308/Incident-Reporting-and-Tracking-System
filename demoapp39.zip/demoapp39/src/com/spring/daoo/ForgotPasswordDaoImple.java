package com.spring.daoo;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.spring.dto.Complaint;
import com.spring.model.*;
import java.util.List;
import com.spring.utility.GenerateRandomNumbers;

import com.hibernate.HibernateUtil;

@Repository
public class ForgotPasswordDaoImple implements ForgotPasswordDao  {

	@Override
	public String forgotPassword(String email) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tr=session.beginTransaction();
		String selectQuery = "from AuthenticationData where email=:Email";
		Query query = session.createQuery(selectQuery);
		query.setParameter("Email", email);

		@SuppressWarnings("unchecked")
		List<AuthenticationData> li = query.list();
		
		String pass = li.get(0).getAuthString();
		String password=GenerateRandomNumbers.customDecode(pass);
		
		return password;
	}
	}