package com.spring.daoo;

import java.util.List;

import com.spring.dto.Complaint;

public interface CommisionerDao {
    public List<Complaint> showComplaintList();
    public void assignTask(int incidentId);
    public List<Complaint> showWardComplaintList(String area);
    public void changeCompleteStatus(int incidentId);
}
