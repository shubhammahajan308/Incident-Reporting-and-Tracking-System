package com.spring.daoo;

import java.util.List;

import com.spring.dto.Complaint;

public interface AdminAcceptDao {
	public void updateIsActiveStatus(int incidentId);
	public void rejectedComplaint(int incidentId);
	public List<Complaint> showComplaintList1();
}
