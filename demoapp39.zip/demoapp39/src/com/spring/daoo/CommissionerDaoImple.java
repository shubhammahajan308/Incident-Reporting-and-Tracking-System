package com.spring.daoo;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.hibernate.HibernateUtil;
import com.spring.dto.Complaint;
@Repository
public class CommissionerDaoImple implements CommisionerDao {
    
	private SessionFactory sessionFactory;
	Session session = HibernateUtil.getSessionFactory().openSession();
	 
	Transaction tx;
	    public void setSessionFactory(SessionFactory sessionFactory) {
	        this.sessionFactory = sessionFactory;
	    }
	
	@Override
	public List<Complaint> showComplaintList() {
		
		Session sess = HibernateUtil.getSessionFactory().openSession();
		sess.beginTransaction();
		String selectQuery = "from Complaint where isactive=:statusFlag and status=:statusState ";
		Query query = sess.createQuery(selectQuery);
		query.setParameter("statusFlag", "true");
		query.setParameter("statusState", "pending");
		@SuppressWarnings("unchecked")
		List<Complaint> li=query.list();
		return li;
		
	}

	@Override
	public void assignTask(int incidentId) {
		Session sess = HibernateUtil.getSessionFactory().openSession();
		Transaction tx1=sess.beginTransaction();
		 @SuppressWarnings("unchecked")
	    Query query=sess.createQuery("update Complaint set status=:statusFlag where incidentId=:inId");
		 query.setParameter("statusFlag", "InProgress");
		 query.setParameter("inId", incidentId);
		query.executeUpdate();
		//now commented **
		tx1.commit();
		//just now added
		sess.close();
		
	}

	@Override
	public List<Complaint> showWardComplaintList(String area) {
		Session sess = HibernateUtil.getSessionFactory().openSession();
		sess.beginTransaction();
		String wardArea=area;
		String selectQuery = "from Complaint where isactive=:statusFlag and status=:statusState and area=:wardArea";
		Query query = sess.createQuery(selectQuery);
		query.setParameter("statusFlag", "true");
		query.setParameter("statusState", "InProgress");
		query.setParameter("wardArea",wardArea);
		@SuppressWarnings("unchecked")
		List<Complaint> li=query.list();
		return li;
		
	}

	@Override
	public void changeCompleteStatus(int incidentId) {
		
		Session sess = HibernateUtil.getSessionFactory().openSession();
		Transaction tx1=sess.beginTransaction();
		 @SuppressWarnings("unchecked")
	    Query query=sess.createQuery("update Complaint set status=:statusFlag where incidentId=:inId");
		 query.setParameter("statusFlag", "Completed");
		 query.setParameter("inId", incidentId);
		query.executeUpdate();
		//now commented **
		tx1.commit();
		//just now added
		sess.close();
	}
	
	

}
