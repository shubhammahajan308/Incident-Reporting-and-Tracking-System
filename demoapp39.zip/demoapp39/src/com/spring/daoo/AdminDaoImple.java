package com.spring.daoo;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;


import com.hibernate.HibernateUtil;
import com.spring.dto.Complaint;
import com.spring.model.User;
@Repository
public class AdminDaoImple implements AdminDao {
    
	private SessionFactory sessionFactory;
	Session session = HibernateUtil.getSessionFactory().openSession();
	 
	Transaction tx;
	    public void setSessionFactory(SessionFactory sessionFactory) {
	        this.sessionFactory = sessionFactory;
	    }
	
	@Override
	public List<Complaint> showComplaintList() {
	    	 
		Session sess = HibernateUtil.getSessionFactory().openSession();
		sess.beginTransaction();
		
		String selectQuery = "from Complaint where isactive=:statusFlag and status=:statusState ";
		Query query = session.createQuery(selectQuery);
		query.setParameter("statusFlag", "false");
		query.setParameter("statusState", "pending");
	  @SuppressWarnings("unchecked")
	   List<Complaint> li=query.list();
		
		return li;
	}

	@Override
	public List<User> listCommissioner() {
		Session sess = HibernateUtil.getSessionFactory().openSession();
		sess.beginTransaction();
		String selectQuery = "from User where role=:roleStatus";
		Query query = session.createQuery(selectQuery);
		query.setParameter("roleStatus", "commissioner");
	  @SuppressWarnings("unchecked")
	   List<User> li=query.list();
		return li;
	}
   
	
}
