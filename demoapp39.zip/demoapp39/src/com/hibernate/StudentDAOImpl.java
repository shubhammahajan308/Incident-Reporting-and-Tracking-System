package com.hibernate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.hibernate.service.ServiceRegistry;


import com.spring.Student;
import com.spring.dto.Complaint;

import com.spring.model.ActivationMaster;
import com.spring.model.AuthenticationData;
import com.spring.model.User;

public class StudentDAOImpl implements StudentDAO{
	
	

	private SessionFactory sessionFactory;
	 Session session = HibernateUtil.getSessionFactory().openSession();
	Transaction tx ;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
   
	@Override
	public int save(Student p) {
		if(!tx.isActive())
		{
			tx=session.beginTransaction();
			int id=(int) session.save(p);
			tx.commit();
			session.close();
			return id;
		}
		else
		{

			int id=(int) session.save(p);
			tx.commit();
			session.close();
			return id;
		}
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Complaint> list() {
		
		session.beginTransaction();
		List<Complaint> personList = session.createQuery("select status,latitude,longitude from Complaint").list();
		session.close();
		return personList;
	}
	
	public static Session getCurrentSessionFromConfig() {
		Configuration config = new Configuration();
		config.configure();
		SessionFactory sessionFactory = config.buildSessionFactory();
		Session session = sessionFactory.getCurrentSession();
		return session;
	}

	public int save(User std) {
		try
		{
			Transaction tx = session.beginTransaction();
			int id=(int) session.save(std);
			tx.commit();
			session.close();
			return id;
		}
		catch(Exception ee)
		{
			return -400;
		}
		
	}
	public String save(ActivationMaster data)
	{
		try
		{
			
			int id=(int) session.save(data);
			session.close();
			if(id>0)
				return "success";
			return "Failed";
		}
		catch(Exception ee)
		{
			return "Error"+ee;
		}
		
	}
	public int save(AuthenticationData data)
	{
		try
		{
				int id=(int) session.save(data);
				session.close();
				return id;
			
			
		}
		catch(Exception ee)
		{
			System.out.print(ee);
			return -400;
		}
		
	}
	public  List<ActivationMaster> listAdmin() {
		session.beginTransaction();
		@SuppressWarnings("unchecked")
		
		List<ActivationMaster> personList = session.createQuery("FROM ActivationMaster").list();
		session.close();
		return personList;
	}
	public  List<ActivationMaster> adminByEmail(String emial) {
		session.beginTransaction();
		@SuppressWarnings("unchecked")
		
		String selectQuery = "FROM ActivationMaster as account WHERE account.email = :emailparam";
		Query query = session.createQuery(selectQuery);
		query.setParameter("emailparam", emial);
		@SuppressWarnings("unchecked")
		List<ActivationMaster> list = query.list();
		
		session.close();
		return list;
	}
	public  int activateUser(String emial) {
		Transaction tx = session.beginTransaction();
		@SuppressWarnings("unchecked")
		
	Query query = session.createQuery("update ActivationMaster set isVerified =:isVerify WHERE email =:user_mail");
	query.setParameter("isVerify", 'Y');
	query.setParameter("user_mail", emial);
	
	int result = query.executeUpdate();
	tx.commit();
		
		session.close();
		return result;
	}
	public  List<AuthenticationData> authByEmail(String emial) {
		Session sess = HibernateUtil.getSessionFactory().openSession();
		sess.beginTransaction();
		
		
		String selectQuery = "FROM AuthenticationData as account WHERE account.email = :emailparam";
		Query query = sess.createQuery(selectQuery);
		query.setParameter("emailparam", emial);
		@SuppressWarnings("unchecked")
		List<AuthenticationData> list = query.list();
		return list;
	}
	
	public int update(AuthenticationData data)
	{
		
		try
		{
			Query query = session.createQuery("update AuthenticationData set authString =:authstr WHERE email =:user_mail");
			query.setParameter("authstr", data.getAuthString());
			query.setParameter("user_mail", data.getEmail());
			
			int result = query.executeUpdate();
			session.close();
			return result;
			
		}
		catch(Exception ee)
		{
			return -400;
		}
		
	}
	
	
	public List<Complaint> getMapList()
	{
		session.beginTransaction();
		Query q = session.createQuery("from Complaint");
		List<Complaint> li = q.list();
		session.flush();
		session.close();
		return li;
	}
	
	public User getUserObject(String name)
	{
		Session sess = HibernateUtil.getSessionFactory().openSession();
	    sess.beginTransaction();
		Query q=sess.createQuery("from User as user WHERE user.email=:emailparam");
		q.setParameter("emailparam", name);
		@SuppressWarnings("unchecked")
		List<User> user=q.list();
		User userObj=user.get(0);
		sess.close();
		return userObj;
	}
	
	public List<Complaint> CaseListByStatus(String status) {
				session.beginTransaction();
				
				String selectQuery = "select area,latitude,longitude from Complaint WHERE status = :statusparam";
				Query query = session.createQuery(selectQuery);
				query.setParameter("statusparam", status);
				@SuppressWarnings("unchecked")
				List<Complaint> list = query.list();
				session.close();
				return list;
			
	}
}
