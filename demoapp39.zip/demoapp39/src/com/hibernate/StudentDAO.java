package com.hibernate;

import java.util.List;

import com.spring.Student;
import com.spring.dto.Complaint;

public interface StudentDAO {

public int save(Student p);
	
	public List<Complaint> list();
	
}
